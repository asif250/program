#include<stdio.h>
void insert(int n,int a[],int pos,int value){
    int i;
    for(i=n;i>=pos-1;i--){
    a[i+1]=a[i];
    }
    a[pos-1]=value;

}
int main(){


int a[100],pos,n,i,j,k,value;
printf("Enter the number of array : ");
scanf("%d",&n);
printf("Enter array element : ");
for(i=0;i<n;i++){
    scanf("%d",&a[i]);
}
printf("The array is : ");

 for(i=0;i<n;i++){
    printf("%d ",a[i]);
}

printf("\nEnter the position and value of array element which you insert : ");

scanf("%d%d",&pos,&value);

insert(n,a,pos,value);
printf("\nThe inserted array is : ");
    for(i=0;i<=n;i++){
    printf("%d ",a[i]);
    }



return 0;
}
