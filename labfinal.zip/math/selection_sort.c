#include<stdio.h>
void selection_sort(int a[],int n){
    int i,j,pos;
    for(i=0;i<n;i++){
        pos=i;
        for(j=i+1;j<n;j++)
        {
            if(a[pos]>a[j]){
                pos=j;
            }

        }
        if(pos!=i){
            int temp=a[i];
            a[i]=a[pos];
            a[pos]=temp;
        }

    }
}
int main()
{
    int a[100],i,j,k,n,pos;
    printf("enter the value of n: ");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    selection_sort(a,n);
    printf("the sorting value: ");

    for(i=0;i<n;i++){
        printf("%d  ",a[i]);
    }
    return 0;
}
