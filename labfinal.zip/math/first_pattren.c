#include<stdio.h>
#include<string.h>
int main()
{
    int i, j, k, l1, l2, flag=0;
    char li[100], mat[20];
    printf("Enter the text : ");
    gets(li);
    l1= strlen(li);
    printf("Enter the text which is find  : ");

    gets(mat);
    l2=strlen(mat);

    for(i=0; i<l1; i++)
    {
        for(j=0, k=0; j<l2; j++, k++)
        {
            if(li[i+k]!=mat[j])
            {
                flag=0;
                break;
            }
            else
            {
                flag++;
            }
        }
        if(flag==l2)
        {
            break;
        }
    }
     printf("%d", i+1);
    return 0;
}
