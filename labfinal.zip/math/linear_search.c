#include<stdio.h>
int main(){

       int a[100],n,i,value,count=0;
    printf("Enter the number of array element : ");
    scanf("%d",&n);
    printf("Enter the element of array : ");
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("\n the array is  : ");
    for(i=0;i<n;i++){
        printf("%d ",a[i]);
    }
    printf("\nEnter the value : ");
    scanf("%d",&value);

    for(i=0;i<n;i++){
        if(a[i]==value){
            printf("\n%d is position at %d \n",value,i+1);
            count++;
        }
    }
        if(count==0){
            printf("\n%d is not present into the array.\n",value);
        }else

            printf("\n%d is %d times into the array\n",value,count);



return 0;
}
