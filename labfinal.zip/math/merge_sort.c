#include<stdio.h>
void mergesort(int a[],int i,int j){
  int mid,b;
  if(i<j){

    mid=(i+j)/2;
    mergesort(a,i,mid);
    mergesort(a,mid+1,j);
    merges(a,i,mid,mid+1,j);
  }

}
void merges(int a[],int m,int p,int n,int q){
    int temp[50];
    int i,k,j;
    k=0;
    i=m;
    j=n;
    while(i<=p && j<=q){
        if(a[i]<a[j])
            temp[k++]=a[i++];
        else
            temp[k++]=a[j++];
    }
    while(i<=p){
        temp[k++]=a[i++];
    }
    while(j<=q){
        temp[k++]=a[j++];
    }
    for(i=m,j=0;i<=q;i++,j++){
        a[i]=temp[j];
    }
}


int main(){
     int a[100],i,j,k,n,pos;
    printf("enter the value of n: ");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    mergesort(a,0,n-1);

    printf("the sorting value: ");

    for(i=0;i<n;i++){
        printf("%d  ",a[i]);
    }
return 0;
}
