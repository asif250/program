#include<stdio.h>

void BubbleSort(int n,int a[]){
    int i,j,temp;
        for(i=0;i<n;i++){
        for(j=0;j<i;j++){
            if(a[i]<a[j]){
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
    }

}
int main(){

    int a[100],n,i,j;
    printf("Enter the number of array element : ");
    scanf("%d",&n);
    printf("Enter the element of array : ");
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("\n the array is  : ");
    for(i=0;i<n;i++){
        printf("%d ",a[i]);
    }

    BubbleSort(n,a);

    printf("\n the sorted array is  : ");
    for(i=0;i<n;i++){
        printf("%d ",a[i]);
    }

return 0;
}
