#include<stdio.h>

int main(){
    int a[100]={0,1,2,3,4,5,6,7,8,9};
    int n,mid,LOC;
    int LB=0;
    int UP=9;
    printf("Enter searching value : ");
    scanf("%d",&n);
    mid=(LB+UP)/2;
    printf("%d\n\n",mid);


    while(LB<=UP && a[mid]!=n){

    if(n<a[mid])
      UP=mid-1;
     else
        LB=mid+1;
     mid=(LB+UP)/2;


    }
    if(a[mid]==n)
        LOC=mid;

    else
        LOC=-1;

    if(LOC==-1)
        printf("%d is not exists into the array.\n",n);
    else
       printf("%d is present at location %d\n",n,LOC+1);

    return 0;
}
